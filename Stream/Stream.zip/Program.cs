﻿using Stream;
using Stream.Classes;
using Stream.Helpers;
using System.Diagnostics;
using System.Xml.Linq;

internal class Program
{
    public static Timer _timer = null;
    public static bool Play = false;

    static void Main(string[] args)
    {
        //WeeklyScheduleGenerator.GenerateWeeklySchedule(DateTime.Now);
        _timer = new Timer(TimerCallback, null, 0, 1000);
        while(true)
        {
            Console.ReadLine();
        }
    }
    private static void TimerCallback(Object o)
    {
        if (Play)
            return;
        Play = true;
        using (var session = NHibernateHelper.OpenSession())
        {
            using (var transaction = session.BeginTransaction())
            {
                var schedules = session.Query<Schedule>().ToList();
                schedules = schedules.Where(x => x.Start <= DateTime.Now && x.Start + x.Episode.Duration > DateTime.Now).ToList();
                if (schedules.Count == 0)
                {
                    Play = false;
                    return;
                }
                var CurentVideo = schedules[0];
                if (CurentVideo.Start == DateTime.Now)
                {
                    Play = true;
                    StreamingVideo(CurentVideo.Episode, new TimeSpan(00, 00, 00));
                }
                else
                {
                    Play = true;
                    TimeSpan proshlo = DateTime.Now - CurentVideo.Start;
                    //TimeSpan TimeStart = new TimeSpan(0, 0, (int)(CurentVideo.Length.TotalSeconds - proshlo.TotalSeconds));
                    StreamingVideo(CurentVideo.Episode, proshlo);
                }
                transaction.Commit();
            }
        }
    }

    public static async Task StreamingVideo(Episode video, TimeSpan ss)
    {

        foreach (Process prc in Process.GetProcessesByName("ffmpeg"))
        {
            //prc.Close();
            prc.Kill();
        }
        string startTimeStr = ss.ToString(@"hh\:mm\:ss");
        // Адрес RTMP-сервера. Замените YOUR_SERVER_IP на реальный IP или домен.
        string rtmpUrl = "rtmp://192.168.88.242/live/stream";

        // Формируем аргументы для FFmpeg:
        // - -re: передача видео с оригинальной скоростью
        // - -i: входной файл
        // - -c:v libx264 -preset fast -b:v 2000k: кодирование видео с нужными параметрами
        // - -c:a aac -b:a 128k: кодирование аудио
        // - -f flv: формат потока (для RTMP)

        //string ForAudio = "";
        //string ForAudio2 = "";
        string ForAudio2 = "-map 0:v";
        string ForAudio = "";

        if (video.EpisodeAudio == null)
        {
            // Если аудио не задано отдельно, берём аудио из видео (если оно есть)
            ForAudio = "";
            ForAudio2 = "";
        }
        else
        {
            // Если аудиофайл задан, отключаем аудио из видеофайла и используем только аудио из второго входа
            ForAudio = $"-i \"https://storage.yandexcloud.net/animebacket/{video.EpisodeAudio}\" -map 1:a";
        }



        string ForSub = "";
        //if (video.EpisodeSubs != null)
        //{
        //    //string absoluteSubPath = Path.GetFullPath(video.EpisodeSubs).Replace("\\", "\\\\").Replace(":", "\\:").Replace("'", "\\'");
        //    //ForSub = $"-vf \"ass='{absoluteSubPath}'\"";
        //    ForSub = $"-vf \"ass='https\\://storage.yandexcloud.net/animebacket/{video.EpisodeSubs}'\"";
        //}
        //-preset fast
        string arguments = $"-re -copyts -ss {startTimeStr} -i \"https://storage.yandexcloud.net/animebacket/{video.EpisodeVideo}\" {ForAudio} {ForSub} {ForAudio2} -c:v libx264 -b:v 2000k -c:a aac -b:a 128k -f flv {rtmpUrl}";
        Console.WriteLine("Запуск трансляции...");

        // Создаем и настраиваем процесс для FFmpeg
        var ffmpegProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "ffmpeg",
                Arguments = arguments,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            }
        };

        // Подписываемся на поток ошибок для вывода логов FFmpeg
        ffmpegProcess.ErrorDataReceived += (sender, e) =>
        {
            if (!string.IsNullOrEmpty(e.Data))
            {
                Console.WriteLine(e.Data);
                File.AppendAllText("log.log", $"{e.Data}\r\n");
            }

        };
        ffmpegProcess.OutputDataReceived += (sender, e) =>
        {
            
            if (!string.IsNullOrEmpty(e.Data))
            {
                File.AppendAllText("log.log", $"{e.Data}\r\n");
            }
        };
        // Запускаем процесс
        ffmpegProcess.Start();
        ffmpegProcess.BeginErrorReadLine();
        ffmpegProcess.BeginOutputReadLine();

        // Дожидаемся завершения процесса трансляции (либо можно реализовать логику для принудительного завершения)
        ffmpegProcess.WaitForExit();
        ffmpegProcess.Close();

        Console.WriteLine("Трансляция завершена.");
        Play = false;
    }
}